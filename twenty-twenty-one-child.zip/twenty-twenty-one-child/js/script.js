// Form tab script
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Email Form Submit

$(document).ready(function(e) {
	const email_form = $("#user-email-upadate-form");
	const email_error_msg = $('.email-error-msg');
	const email_success_msg = $('.email-success-msg');
	
	$(email_form).submit( function(event) {
		event.preventDefault(), event.stopPropagation();
		email_form.addClass('was-validated');
		
		$( email_error_msg, email_success_msg ).removeClass('show');
		
		if( email_form[0].checkValidity() ) {
			const data = {
				email : $('#user-email').val(),
				confirm_email : $('#user-email-confirm').val(),
				nonce : ajax_handler.nonce
			};

			const config = { 
				method : 'POST',
				headers: { 'Content-Type' : 'application/json' },
				body : JSON.stringify(data),
			};
			
			fetch( `${ajax_handler.ajaxurl}?action=user_email_update_request`, config )
			.then(response => response.json())
			.then(result => {
				if( result.success ) {
					email_success_msg.text(result.data).addClass('show');
					$("#user-email-upadate-form button[type=reset]").trigger('click');
					setTimeout(function(){
						email_success_msg.removeClass('show').empty();
					}, 3000)
				} else {
					email_error_msg.text(result.data).addClass('show');
				}
			})
			.catch((error) => {
				email_error_msg.text(error).addClass('show');
			});
		}
	});
	
	$("#user-email-upadate-form button[type=reset]").click(function(e){
		$(email_form).removeClass('was-validated');
	});
	
	const password_form = $("#user-password-upadate-form");
	const password_error_msg = $('.password-error-msg');
	const password_success_msg = $('.password-success-msg');
	
	$(password_form).submit( function(event) {
		event.preventDefault(), event.stopPropagation();
		password_form.addClass('was-validated');
		
		$( password_error_msg, password_error_msg ).removeClass('show');
		
		if( password_form[0].checkValidity() ) {
			const data = {
				password : $('#user-passowrd').val(),
				new_password : $('#user-passowrd-new').val(),
				nonce : ajax_handler.nonce
			};

			const config = { 
				method : 'POST',
				headers: { 'Content-Type' : 'application/json' },
				body : JSON.stringify(data),
			};
			
			fetch( `${ajax_handler.ajaxurl}?action=user_password_update_request`, config )
			.then(response => response.json())
			.then(result => {
				if( result.success ) {
					password_success_msg.text(result.data).addClass('show');
					$("#user-password-upadate-form button[type=reset]").trigger('click');
					window.location.reload();
					setTimeout(function(){
						password_success_msg.removeClass('show').empty();
					}, 3000)
				} else {
					password_error_msg.text(result.data).addClass('show');
				}
			})
			.catch((error) => {
				password_error_msg.text(error).addClass('show');
			});
		}
	});
	
	$("#user-password-upadate-form button[type=reset]").click(function(e){
		$(password_form).removeClass('was-validated');
	});
});

