<?php

// Queue parent style followed by child/customized style
add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', PHP_INT_MAX);

function theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'parent-style' ) );
	wp_register_script( 'jquery-js','https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js'); 
    wp_enqueue_script( 'jquery-js' );
    // bootstrap-js
    wp_enqueue_style( 'animate-css', 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css');
    wp_enqueue_style( 'bootstrap-css', get_stylesheet_directory_uri() .'/css/bootstrap.min.css');
    wp_enqueue_style( 'header-css', get_stylesheet_directory_uri() .'/css/header.css');
    wp_enqueue_style( 'sidebar-css', get_stylesheet_directory_uri() .'/css/sidebar.css');
    wp_enqueue_style( 'footer-css', get_stylesheet_directory_uri() .'/css/footer.css');
    wp_register_script( 'custom-js',get_stylesheet_directory_uri() .'/js/script.js', array(), filemtime(get_stylesheet_directory() . '/js/script.js'), true);
    wp_enqueue_script( 'custom-js' );
    wp_register_script( 'bootstrap-js',get_stylesheet_directory_uri() .'/js/bootstrap.min.js'); 
    wp_enqueue_script( 'bootstrap-js' );
    
    wp_register_script( 'fontawesome-js','https://kit.fontawesome.com/419ef19739.js'); 
    wp_enqueue_script( 'fontawesome-js' );
	
	wp_localize_script('custom-js', 'ajax_handler', [
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'home_url' => home_url(),
		'nonce' => wp_create_nonce('admin-ajax'),
	]);
}

// Login after redirect page
function my_login_redirect( $redirect_to, $request, $user ) {
    //is there a user to check?
    if ( isset( $user->roles ) && is_array( $user->roles ) ) {
        //check for admins
        if ( in_array( 'administrator', $user->roles ) ) {
            // redirect them to the default place
            return admin_url();
        } else {
            return home_url();
        }
    } else {
        return home_url();
    }
}
add_filter( 'login_redirect', 'my_login_redirect', 10, 3 );


// user not login to go login page
add_action( 'template_redirect', 'redirect_non_logged_users_to_specific_page' );
function redirect_non_logged_users_to_specific_page() {
	if( !is_user_logged_in() && $_SERVER['PHP_SELF'] != '/wp-admin/admin-ajax.php' ) {
		wp_redirect( home_url('wp-login.php') );
		exit;
	}
}

add_action( 'wp_ajax_user_email_update_request', 'user_email_update_request' );
add_action( 'wp_ajax_nopriv_user_email_update_request', 'user_email_update_request' );
function user_email_update_request() {
	$valid = false;
	
	$msg = "Something went wrong, please try again";
	
	$object = json_decode( file_get_contents('php://input') );
	
	if( $object && wp_verify_nonce( $object->nonce, 'admin-ajax' ) ) {
		
		$user_id = get_current_user_id();
		
		if( is_user_logged_in() ) {
			
			$user_info = get_userdata( $user_id );
			
			$user_current_email = $user_info->user_email;
			
			$email = sanitize_email( $object->email );
			
			$confirm_email = sanitize_email( $object->confirm_email );
			
			if( ! is_email( $email ) ) {
				
				$msg = "Please enter valid old email address.";
				
			} else if( ! is_email( $confirm_email ) ) {
				
				$msg = "Please enter valid new email address.";
				
			} else if( ! email_exists( $email ) && $user_current_email != $email ) {
				
				$msg = "Old email address not match your email.";
				
			} else if( email_exists( $confirm_email ) ) {
				
				$msg = "New email address already in use, try another email.";
				
			} else if( $user_current_email == $email && email_exists( $email ) == $user_id ) {
				
				$args = [ 'ID' => $user_id, 'user_email' => $confirm_email ];
				
				$user = wp_update_user( $args );
				
				if( ! is_wp_error( $user ) ) {
					
					$msg = "Successfully update email address.";
					$valid = true;
					
				} else {
					
					$msg = $user->get_error_message();
					
				}
				
			}
			
		} else {
			
			$msg = "please login to continue your email address change.";
			
		}
		
	} else {
		$msg = "Something went wrong, please try again";
	}
	
	if( $valid ) {
		wp_send_json_success( $msg );
	} else {
		wp_send_json_error($msg);
	}
}

add_action( 'wp_ajax_user_password_update_request', 'user_password_update_request' );
add_action( 'wp_ajax_nopriv_user_password_update_request', 'user_password_update_request' );
function user_password_update_request() {
	$valid = false;
	
	$msg = "Something went wrong, please try again";
	
	$object = json_decode( file_get_contents('php://input') );
	
	if( $object && wp_verify_nonce( $object->nonce, 'admin-ajax' ) ) {
		
		$user_id = get_current_user_id();
		
		if( is_user_logged_in() ) {
			
			$user_info = get_userdata( $user_id );
			
			$user_login = $user_info->data->user_login;

			$user_current_pass = $user_info->data->user_pass;
			
			$password = $object->password;
			
			$new_password = $object->new_password;
			
			if( $password != $new_password ) {
				
				if( wp_check_password( $password, $user_current_pass, $user_id ) ) {
					
					wp_set_password( $new_password, $user_id );
					
					wp_logout();
					
					$msg = "Successfully update password.";
					$valid = true;
					
				} else {
					
					$msg ="your password don't match current password";
					
				}
				
			} else {
				
				$msg = "old password and new password cannot be same";
				
			}
			
			
		} else {
			
			$msg = "please login to continue your password change.";
			
		}
		
	}
	
	if( $valid ) {
		wp_send_json_success( $msg );
	} else {
		wp_send_json_error($msg);
	}
}
/*
 * Hide admin br for user who is not contacin amdin role.!
 */
add_action('after_setup_theme', 'remove_admin_bar');
	function remove_admin_bar() {
	if (current_user_can('subscriber')) {
	show_admin_bar(false);
	}
}