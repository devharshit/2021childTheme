<section class="main-content-area">
    <div class="container">
        <div class="row page-breadcrumb-wrap">
            <div class="col-md-12">
                <div class="page-breadcrumb"><h2>Settings</h2><span><a href="#"><i class="fa fa-home" aria-hidden="true"></i></a>/ Settings </span></div>
            </div>
        </div>
        <div class="row page-profile-settings">
            <div class="col-md-12 profile-setting-tab" >
                <form method="post">
                    <div class="tab-list">
                        <ul class="tab">
                            <li><a class="tablinks" onclick="openTab(event, 'plansetting')"><i class="fa fa-dollar-sign"></i> Plan Settings</a></li>
                            <li><a class="tablinks" onclick="openTab(event, 'paymentsetting')"><i class="fa fa-credit-card"></i> Payment Settings</a></li>
                            <li><a class="tablinks active" onclick="openTab(event, 'changeemail')"><i class="fa fa-envelope"></i> Email Settings</a></li>
                            <li><a class="tablinks" onclick="openTab(event, 'changepassword')"><i class="fa fa-lock"></i>Password Settings</a></li>
                        </ul>
                    </div>
                    <div class="tab-content-wrap">
                        <div id="plansetting" class="tabcontent animate__animated animate__fadeInUp">
                            <h1>Plan Setting</h1>
                        </div>
                        <div id="paymentsetting" class="tabcontent animate__animated animate__fadeInUp">
                            <h1>Payment Setting</h1>
                        </div>
                        <div id="changeemail" class="tabcontent animate__animated animate__fadeInUp"  style="display: block;">
                            <div class="form-group">
                                <fieldset>
                                    <legend>Enter Old Email address</legend>
                                    <input type="email" name="user-email" class="form-control">
                                </fieldset>
                            </div>
                            <div class="form-group">
                                <fieldset>
                                    <legend>Enter New Email address</legend>
                                    <input type="email" name="user-email-confirm" class="form-control">
                                </fieldset>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="submit-profile-change" class="btn btn-primary">Change Email</button>
                                <button type="reset" class="btn btn-info">cancel</button>
                            </div>
                        </div>
                        <div id="changepassword" class="tabcontent animate__animated animate__fadeInUp">
                            <div class="form-group">
                                <fieldset>
                                <legend>Enter Old Password</legend>
                                    <input type="password" name="old-user-passowrd" class="form-control">
                                </fieldset>
                            </div>
                            <div class="form-group">
                                <fieldset>
                                    <legend>Enter New Password</legend>
                                    <input type="password" name="new-user-passowrd" class="form-control">
                                </fieldset> 
                            </div>
                            <div class="form-group">
                                <button type="submit" name="submit-profile-change" class="btn btn-primary">Change Password</button>
                                <button type="reset" class="btn btn-info">cancel</button>
                            </div>
                        </div>
                    </div>        
                </form>
            </div>
        </div>
    </div>
</section>