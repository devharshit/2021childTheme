<?php 
/* 
*
* Template Name: User Dashboard
*
*/

get_header();
// if( have_posts() ) : while( have_posts() ) : the_post(); ?>
<section class="main-content-area">
    <div class="container-fluid">
        <div class="row page-breadcrumb-wrap">
            <div class="col-md-12">
                <div class="page-breadcrumb"><h2>Settings</h2><span><a href="#"><i class="fa fa-home" aria-hidden="true"></i></a>/ Settings </span></div>
            </div>
        </div>
        <div class="row page-profile-settings">
            <div class="col-md-12 profile-setting-tab" >
				<div class="tab-list">
					<ul class="tab">
						<li><a class="tablinks" onclick="openTab(event, 'plansetting')"><i class="fa fa-dollar-sign"></i> Plan Settings</a></li>
						<li><a class="tablinks" onclick="openTab(event, 'paymentsetting')"><i class="fa fa-credit-card"></i> Payment Settings</a></li>
						<li><a class="tablinks active" onclick="openTab(event, 'changeemail')"><i class="fa fa-envelope"></i> Email Settings</a></li>
						<li><a class="tablinks" onclick="openTab(event, 'changepassword')"><i class="fa fa-lock"></i>Password Settings</a></li>
					</ul>
				</div>
				<div class="tab-content-wrap">
					<div id="plansetting" class="tabcontent animate__animated animate__fadeInUp">
						<h1>Plan Setting</h1>
					</div>
					<div id="paymentsetting" class="tabcontent animate__animated animate__fadeInUp">
						<h1>Payment Setting</h1>
					</div>
					<div id="changeemail" class="tabcontent animate__animated animate__fadeInUp"  style="display: block;">
						<form method='post' class='user-email-form needs-validation' id='user-email-upadate-form' novalidate>
							<div class="form-group">
								<fieldset>
									<legend>Enter Old Email address</legend>
									<input type="email" name="user-email" id="user-email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
								</fieldset>
								<div class="invalid-feedback old-email-feedback">Please enter valid email address.</div>
							</div>
							<div class="form-group">
								<fieldset>
									<legend>Enter New Email address</legend>
									<input type="email" name="user-email-confirm" id="user-email-confirm" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" required>
								</fieldset>
								<div class="invalid-feedback new-email-feedback">Please enter valid email address.</div>
							</div>
							<div class="form-group">
								
								<p class='text-danger email-error-msg collapse'></p>
								<p class='text-success email-success-msg collapse'></p>
								
								<button type="submit" name="submit-profile-change" class="btn btn-primary">Change Email</button>
								<button type="reset" class="btn btn-info">cancel</button>
							</div>
						</form>
					</div>
					<div id="changepassword" class="tabcontent animate__animated animate__fadeInUp">
						<form method='post' class='user-password-form needs-validation' id='user-password-upadate-form' novalidate>
							<div class="form-group">
								<fieldset>
									<legend>Enter Old Password</legend>
									<input type="password" name="user-passowrd" id="user-passowrd" class="form-control" required>
								</fieldset>
								<div class="invalid-feedback new-password-feedback">Please enter valid password.</div>
							</div>
							<div class="form-group">
								<fieldset>
									<legend>Enter New Password</legend>
									<input type="password" name="user-passowrd-confirm" id="user-passowrd-new" class="form-control" required>
								</fieldset> 
								<div class="invalid-feedback new-password-feedback">Please enter valid password.</div>
							</div>
							<div class="form-group">
								<p class='text-danger password-error-msg collapse'></p>
								<p class='text-success password-success-msg collapse'></p>
								
								<button type="submit" name="submit-profile-change" class="btn btn-primary">Change Password</button>
								<button type="reset" class="btn btn-info">cancel</button>
							</div>
						</form>
					</div>
				</div>
            </div>
        </div>
    </div>
</section>
<?php //endwhile; endif;
get_footer(); 
?>