<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'twentytwentyone' ); ?></a>
<?php 
$userLogout = site_url().'/wp-login.php?action=logout';
 $siteLogo = get_stylesheet_directory_uri() . "/img/site-logo.jpg";
 $userIconThumb = get_stylesheet_directory_uri() . "/img/user-img.jpg";
?>
    <!-- Sidebar Section -->
    <section class="section-sidebar">
        <div class="header-logo-full">
            <img src="<?php echo $siteLogo;?>">
        </div>
        <div class="site-sidebar-nav">
            <ul class="nav-menu-list">
                <li><a class="" href="#"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
                <li><a class="" href="#"><i class="fa fa-clipboard-list" aria-hidden="true"></i> My Appointments</a></li>
                <li><a class="" href="#"><i class="fa fa-user-friends" aria-hidden="true"></i> Profile Mangement</a></li>
                <li><a class="active" href="#"><i class="fa fa-cog" aria-hidden="true"></i> Setting</a></li>
                <li><a class="" href="<?php echo $userLogout;?>"><i class="fa fa-power-off" aria-hidden="true"></i> Log Out</a></li>
            </ul>
        </div>
    </section>
    <!-- Sidebar END -->
    <?php //get_template_part( 'template-parts/header/site-header' ); ?>
    <header id="masthead" class="site-header has-title-and-tagline" role="banner">
        <div class="nav-toggle">
            <a href="#"><i class="fa fa-bars"></i></a>
        </div>
        <div class="user-info">
            <a class="view-full-screen" href="#"><i class="fas fa-expand"></i></a>
            <a class="user-icon" href="#"><img src="<?php echo $userIconThumb;?>"></a>
        </div>
        </header>
	<div id="content" class="site-content">
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">
